# Nest Task API

NestJS-based REST API with PostgreSQL, TypeORM, JWT authentication, input validation, error handling, and unit tests.

## Features

- NestJS + TypeORM + PostgreSQL
- Users & Tasks domain
- JWT-based Authentication (`/auth/register`, `/auth/login`)
- Role-based Authorization (Admin vs User)
- CRUD for Users (admin-only) and Tasks (per-user, admin can see all)
- Input validation using `class-validator`
- Global error handling via Nest's built-in exceptions
- Unit tests with Jest for core services
- Ready to push to Git (GitHub)

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Update with your PostgreSQL credentials.

### 3. Run PostgreSQL

Make sure PostgreSQL is running and a database exists with the name provided in `.env` (`DB_NAME`).

### 4. Run the app

```bash
npm run start:dev
```

The server will start at `http://localhost:3000`.

### 5. Run tests

```bash
npm test
```

## API Overview

### Auth

- `POST /auth/register` – Register a new user
- `POST /auth/login` – Login and receive a JWT

### Users (Admin only, requires Bearer token)

- `GET /users` – List all users
- `GET /users/:id` – Get single user
- `POST /users` – Create user
- `PATCH /users/:id` – Update user
- `DELETE /users/:id` – Delete user

### Tasks (Authenticated users)

- `GET /tasks` – List tasks for current user (admin: all tasks)
- `GET /tasks/:id` – Get task (must own or be admin)
- `POST /tasks` – Create new task
- `PATCH /tasks/:id` – Update a task
- `DELETE /tasks/:id` – Delete a task

## GitHub

1. Initialize Git:

```bash
git init
git add .
git commit -m "Initial Nest Task API"
```

2. Create a new repository on GitHub.

3. Add remote & push:

```bash
git remote add origin https://github.com/<your-username>/<your-repo>.git
git branch -M main
git push -u origin main
```

You can now share this as a complete backend project.
