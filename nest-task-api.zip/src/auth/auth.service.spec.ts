import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { UsersService } from '../users/users.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import { UserRole } from '../users/user-role.enum';

describe('AuthService', () => {
  let service: AuthService;
  let usersService: Partial<UsersService>;
  let jwtService: Partial<JwtService>;

  beforeEach(async () => {
    usersService = {
      findByEmail: jest.fn(),
      create: jest.fn(),
    } as any;

    jwtService = {
      signAsync: jest.fn().mockResolvedValue('token'),
    } as any;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: UsersService, useValue: usersService },
        { provide: JwtService, useValue: jwtService },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
  });

  it('register throws if email exists', async () => {
    (usersService.findByEmail as jest.Mock).mockResolvedValue({ id: 1 });
    await expect(
      service.register({
        email: 'a@a.com',
        password: 'password',
      } as any),
    ).rejects.toThrow(ConflictException);
  });

  it('login throws if user not found', async () => {
    (usersService.findByEmail as jest.Mock).mockResolvedValue(null);
    await expect(
      service.login({ email: 'a@a.com', password: 'password' }),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('login throws if password mismatch', async () => {
    (usersService.findByEmail as jest.Mock).mockResolvedValue({
      id: 1,
      email: 'a@a.com',
      password: await bcrypt.hash('other', 10),
      role: UserRole.USER,
    });
    await expect(
      service.login({ email: 'a@a.com', password: 'password' }),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('login returns token when success', async () => {
    const hash = await bcrypt.hash('password', 10);
    (usersService.findByEmail as jest.Mock).mockResolvedValue({
      id: 1,
      email: 'a@a.com',
      password: hash,
      role: UserRole.USER,
    });
    const res = await service.login({
      email: 'a@a.com',
      password: 'password',
    });
    expect(res.access_token).toBe('token');
  });
});
