import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TasksService } from './tasks.service';
import { Task } from './task.entity';
import { UserRole } from '../users/user-role.enum';

describe('TasksService', () => {
  let service: TasksService;
  let repo: Repository<Task>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TasksService,
        {
          provide: getRepositoryToken(Task),
          useClass: Repository,
        },
      ],
    }).compile();

    service = module.get<TasksService>(TasksService);
    repo = module.get<Repository<Task>>(getRepositoryToken(Task));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('findAllForUser admin returns all', async () => {
    const user: any = { id: 1, role: UserRole.ADMIN };
    const tasks = [{ id: 1 } as Task];
    jest.spyOn(repo, 'find').mockResolvedValue(tasks as any);

    const res = await service.findAllForUser(user);
    expect(res).toEqual(tasks);
  });
});
