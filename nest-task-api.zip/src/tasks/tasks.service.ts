import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Task } from './task.entity';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { User } from '../users/user.entity';
import { UserRole } from '../users/user-role.enum';

@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task)
    private readonly tasksRepo: Repository<Task>,
  ) {}

  async findAllForUser(user: User): Promise<Task[]> {
    if (user.role === UserRole.ADMIN) {
      return this.tasksRepo.find();
    }
    return this.tasksRepo.find({ where: { owner: { id: user.id } } });
  }

  async findOneForUser(id: number, user: User): Promise<Task> {
    const task = await this.tasksRepo.findOne({
      where: { id },
      relations: ['owner'],
    });
    if (!task) throw new NotFoundException(`Task #${id} not found`);

    if (user.role !== UserRole.ADMIN && task.owner.id !== user.id) {
      throw new ForbiddenException('You do not own this task');
    }
    return task;
  }

  async create(createTaskDto: CreateTaskDto, user: User): Promise<Task> {
    const task = this.tasksRepo.create({
      ...createTaskDto,
      owner: user,
    });
    return this.tasksRepo.save(task);
  }

  async update(
    id: number,
    updateTaskDto: UpdateTaskDto,
    user: User,
  ): Promise<Task> {
    const task = await this.findOneForUser(id, user);
    Object.assign(task, updateTaskDto);
    return this.tasksRepo.save(task);
  }

  async remove(id: number, user: User): Promise<void> {
    const task = await this.findOneForUser(id, user);
    await this.tasksRepo.remove(task);
  }
}
