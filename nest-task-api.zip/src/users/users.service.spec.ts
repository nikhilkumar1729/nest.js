import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { UsersService } from './users.service';
import { User } from './user.entity';
import { UserRole } from './user-role.enum';

describe('UsersService', () => {
  let service: UsersService;
  let repo: Repository<User>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        {
          provide: getRepositoryToken(User),
          useClass: Repository,
        },
      ],
    }).compile();

    service = module.get<UsersService>(UsersService);
    repo = module.get<Repository<User>>(getRepositoryToken(User));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('create hashes password', async () => {
    const saveSpy = jest
      .spyOn(repo, 'save')
      .mockImplementation(async (u: any) => u as any);
    jest.spyOn(repo, 'create').mockImplementation((u: any) => u as any);

    const dto = { email: 'test@example.com', password: 'password' };
    const result = await service.create(dto as any);

    expect(saveSpy).toHaveBeenCalled();
    expect(result.password).not.toBe(dto.password);
  });

  it('findOne throws if not found', async () => {
    jest.spyOn(repo, 'findOne').mockResolvedValue(null);
    await expect(service.findOne(1)).rejects.toThrow('User #1 not found');
  });

  it('update hashes new password', async () => {
    const existing: any = {
      id: 1,
      email: 'a@a.com',
      password: 'old',
      role: UserRole.USER,
    };
    jest.spyOn(service, 'findOne').mockResolvedValue(existing);
    const saveSpy = jest
      .spyOn(repo, 'save')
      .mockImplementation(async (u: any) => u);
    const dto: any = { password: 'newpassword' };

    const result = await service.update(1, dto);

    expect(saveSpy).toHaveBeenCalled();
    const isMatch = await bcrypt.compare('newpassword', result.password);
    expect(isMatch).toBe(true);
  });
});
